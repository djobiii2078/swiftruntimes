from time import sleep 
import datetime 

def main(args):
    start = datetime.datetime.now() 
    sleep_time = args.get("param1", 5)
    ####################print("Sleeping for [", sleep_time, "s]")
    sleep(sleep_time) 
    end_time = datetime.datetime.now()
    return {"result" : sleep_time, "start": datetime.datetime.timestamp(start), "total_time": (end_time - start)/datetime.timedelta(microseconds=1) }

#test function 
#keep commented if creating a function 

#########print(main({"param1": 5}))


