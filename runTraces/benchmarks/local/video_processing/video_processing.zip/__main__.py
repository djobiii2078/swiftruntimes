import ffmpeg 

def main(args):
    path_video = args.get('file','input.mp4')
    output_video = args.get('output','output.mp4')
    input_file = ffmpeg.input("resources/"+path_video)
    output_file = ffmpeg.output(input_file.trim(start_frame=100, end_frame=1800), output_video)
    ffmpeg.run(output_file,cmd="/usr/bin/ffmpeg",overwrite_output=True)

    return { 'result' : output_video }


#should be commented 
#when launching in the function 
#############print(main({'file': 'input.mp4', 'output': 'output_video.mp4'}))
