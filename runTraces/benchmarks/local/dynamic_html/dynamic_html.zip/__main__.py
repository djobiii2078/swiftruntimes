from datetime import datetime                                                   
from random import sample  
from os import path
from time import time                                                           
import os

from jinja2 import Template

#SCRIPT_DIR = path.abspath(path.join(path.dirname(__file__)))

def main(args):

    # start timing
    name = args.get('username','djobiii2078')
    size = args.get('random_len',10000)
    cur_time = datetime.now()
    random_numbers = sample(range(0, 1000000), size)
    template = Template( open('resources/template.html', 'r').read())
    html = template.render(username = name, cur_time = cur_time, random_numbers = random_numbers)

    end_time = datetime.now() 
    # end timing
    # dump stats 
    return {'result': html, 'start': datetime.datetime.timestamp(cur_time), 'total_time': (end_time - cur_time)/datetime.timedelta(microseconds=1)}

# should be commented 
# if not used for debugging 

######################print(main({'username': 'djobiii2078', 'random_len': 512}))
